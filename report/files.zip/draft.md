---
title: "Disturbance-Robustness Evaluation of a PPO Hover-Stabilize Policy"
subtitle: "AGERE Project — CF2X Quadrotor, PyBullet Simulation"
date: "September 2026"
---

## Executive Summary

This report evaluates the disturbance robustness of a PPO-trained hover-stabilize policy for a CF2X quadrotor, under a curriculum of three disturbance types (velocity kick, torque/spin kick, sustained wind) at five severity levels each. The evaluated checkpoint was swept against all 15 type-level combinations with 40 forced episodes per combination (600 episodes total), rather than relying on the random sampling used during training, so every combination has an equal, deliberate sample size.

Overall crash rate across the full sweep was **21.8%**. Results vary sharply by disturbance type: **wind is fully mastered (0% crash rate at every level)**; **velocity kicks are handled well up to moderate severity** (7.5% crash rate through level 3, rising to 77.5% at the most severe level); **torque disturbances are the policy's clear weak point**, with crash rate climbing far more steeply (45% by level 3, 85% at level 5) and peak tilt angles at the highest level averaging 87 degrees — consistent with genuine loss of control rather than a brief, recoverable maneuver.

A secondary finding emerged from the data that was not anticipated going in: at matched disturbance magnitude, recovery outcomes split into two clusters — near-instant recovery versus recovery taking 15–45+ control steps — for both kick and torque disturbances. Magnitude alone does not explain this split. The most likely explanation is disturbance direction (currently randomized but not logged), which this report flags as an open item rather than a confirmed conclusion.

## 1. Background

The AGERE project trains a PPO policy (Stable-Baselines3) to hold a CF2X quadrotor at a fixed target position in a PyBullet simulation (gym-pybullet-drones' `HoverAviary`). Beyond basic position-holding, the current focus is robustness to mid-episode disturbances, structured as a 3-type by 5-level curriculum:

- **Kick** — an instantaneous velocity impulse (m/s), simulating a physical bump.
- **Torque** — an instantaneous angular-velocity impulse (rad/s), simulating a spin-inducing event such as prop wash or a minor collision.
- **Wind** — a sustained force (N) applied for a fixed window, simulating continuous wind pressure.

Each episode samples at most one disturbance event; level (1 weakest to 5 strongest) determines the range from which the event's magnitude is drawn, with direction sampled uniformly at random in 3D. Full design rationale is in `docs/architecture/hover-disturbance-3x5-design.md`.

## 2. Development Journey

The current checkpoint is the result of an iterative process that is worth summarizing, since it materially affects how the results below should be read.

Two early training pushes plateaued at approximately 37% crash rate with no further improvement from additional training steps. Rather than continuing to spend compute on more training or hyperparameter changes, a diagnostic tool (`hover_tilt_diagnostic.py`) was built to test whether the *measurement* — specifically, the crash-truncation criterion — was the actual ceiling, rather than the policy itself.

That diagnostic found the crash check was truncating episodes the instant tilt crossed a fixed threshold, with no hold-time requirement — unlike the codebase's own recovery criterion, which requires threshold compliance to be *sustained* for a number of steps before counting as recovered. As a result, a policy correctly executing a brief hard-tilt recovery maneuver was being scored identically to one genuinely losing control. Roughly 68% of tilt-truncated episodes, when given room under a loosened bound, recovered cleanly and finished within normal position-error tolerance.

Fixing the crash criterion to require a sustained tilt breach (mirroring the existing recovery-hold pattern) dropped crash rate from 37% to 23% on the *same, already-trained checkpoint* — confirming the earlier plateaus were an artifact of a broken measurement, not a real policy limit. Two further training runs after the fix (`tiltfix`, `tiltfix2`) showed genuine improvement. A third continuation (`tiltfix3`) plateaued again, and separately surfaced a new, not-yet-understood pattern: some kick-disturbance episodes recover cleanly and then destabilize again later with no new disturbance event.

**This report evaluates `tiltfix2`, not `tiltfix3`.** Per the project's own standing rule — evaluate and report the best-performing checkpoint by measurement, not simply the most recent one — `tiltfix2` is the last checkpoint confirmed to still be improving, while `tiltfix3`'s plateau and open late-instability question make it a less trustworthy choice for a headline robustness figure until that pattern is understood. This is revisited in Section 5.

## 3. Methodology

**Checkpoint evaluated:** `hover_stabilize_ppo_seed0_disturbance_3x5_tiltfix2.zip`
**Evaluation method:** forced disturbance sweep — for each of the 3 types and 5 levels, the environment's disturbance sampler was overridden to force that specific (type, level) combination every episode (magnitude still drawn randomly within the level's defined range, as in training; only type and level are fixed). This differs from standard evaluation, which samples type/level/magnitude randomly per episode to match the training distribution — appropriate for an aggregate crash-rate figure, but insufficient for a clean per-bucket breakdown, since 15 buckets sampled randomly do not receive equal or guaranteed coverage.
**Episodes per bucket:** 40 (600 total)
**Policy execution:** deterministic (no exploration noise)
**Seed:** 0 (varied per bucket to avoid replaying an identical start condition across all 15 buckets)

Full reproducibility record (model path, git commit, exact arguments, timestamp) is in `source_manifest.json` alongside this report; raw per-episode data is in `raw_episodes.csv` / `raw_episodes_full.jsonl` under `results/tiltfix2_champion/`.

## 4. Results

### 4.1 Summary Table

| Type | Level | n | Crash rate | Recovery rate | Mean recovery (steps) | Mean magnitude | Mean peak tilt | Mean final pos error (m) |
|---|---|---|---|---|---|---|---|---|
| kick | L1 | 40 | 0.0% | 100.0% | 0.0 | 0.392 m/s | 16.5 deg | 0.022 |
| kick | L2 | 40 | 2.5% | 97.5% | 1.3 | 0.666 m/s | 19.3 deg | 0.032 |
| kick | L3 | 40 | 7.5% | 92.5% | 10.1 | 0.965 m/s | 22.9 deg | 0.041 |
| kick | L4 | 40 | 37.5% | 60.0% | 15.5 | 1.25 m/s | 29.0 deg | 0.162 |
| kick | L5 | 40 | 77.5% | 20.0% | 32.4 | 1.745 m/s | 37.5 deg | 0.378 |
| torque | L1 | 40 | 0.0% | 100.0% | 0.0 | 1.533 rad/s | 13.9 deg | 0.023 |
| torque | L2 | 40 | 10.0% | 90.0% | 1.4 | 3.055 rad/s | 17.5 deg | 0.04 |
| torque | L3 | 40 | 45.0% | 55.0% | 4.5 | 5.15 rad/s | 27.6 deg | 0.091 |
| torque | L4 | 40 | 62.5% | 37.5% | 6.0 | 7.476 rad/s | 38.0 deg | 0.089 |
| torque | L5 | 40 | 85.0% | 15.0% | 5.8 | 11.079 rad/s | 87.4 deg | 0.128 |
| wind | L1 | 40 | 0.0% | 100.0% | 0.0 | 0.03 N | 13.7 deg | 0.02 |
| wind | L2 | 40 | 0.0% | 100.0% | 0.0 | 0.053 N | 13.8 deg | 0.022 |
| wind | L3 | 40 | 0.0% | 100.0% | 0.0 | 0.085 N | 14.7 deg | 0.019 |
| wind | L4 | 40 | 0.0% | 100.0% | 0.0 | 0.118 N | 13.5 deg | 0.023 |
| wind | L5 | 40 | 0.0% | 100.0% | 0.0 | 0.159 N | 14.4 deg | 0.022 |

### 4.2 Crash Rate vs. Disturbance Level

![Crash rate vs. disturbance level, by type](figures/crash_rate_by_level.png)

Crash rate rises with severity for both kick and torque, but at very different rates. Kick stays under 10% through level 3 and only becomes severe at levels 4–5. Torque crosses 45% by level 3 alone — roughly the same crash rate kick doesn't reach until level 5. Wind never produces a crash at any tested level.

### 4.3 Peak Tilt vs. Disturbance Magnitude

![Peak tilt vs. disturbance magnitude, by type](figures/peak_tilt_vs_magnitude.png)

This is the direct force-vector-to-effect view: each point is one episode, magnitude in that disturbance type's own physical unit against the peak tilt angle reached. Kick and wind stay in a bounded, gently-sloped band (wind clustered under 25 degrees regardless of magnitude; kick climbing gradually to the high 30s). Torque is qualitatively different — beyond roughly magnitude 8 rad/s, tilt values scatter widely up to nearly 180 degrees, indicating the drone is being fully inverted in a meaningful fraction of episodes, not just tilted hard.

### 4.4 Recovery Time vs. Magnitude

![Recovery time vs. magnitude, recovered episodes only](figures/recovery_time_vs_magnitude.png)

Restricted to episodes that did recover. The notable feature is not a trend line but a split: at a given magnitude, recovery time clusters near zero for a subset of episodes and 15–45+ steps for another subset, for both kick and torque. See Section 5.2 for discussion.

### 4.5 Wind: Steady-State Error vs. Magnitude

![Wind steady-state error vs. magnitude](figures/wind_steady_state_error_vs_magnitude.png)

Wind never crashes the policy, so its effect is better characterized by steady-state position error while the wind window is active rather than by crash/recovery. Error grows mildly and roughly monotonically with wind force, staying under 0.07 m even at the strongest tested level — well within the project's Stage 2 position-error bar of 0.3 m.

## 5. Discussion

### 5.1 Torque is the binding constraint on robustness, not kick

Kick was the disturbance type most discussed in earlier debugging (it was the mechanism behind the original Stage 1a single-kick design), which could suggest it is the harder case. This sweep shows the opposite: torque crashes far more readily at moderate severity and produces genuinely extreme tilt outcomes at high severity, consistent with real loss of control rather than a truncation-criterion artifact (the sustained-hold tilt fix, described in Section 2, is already applied in this checkpoint). If further training is pursued, torque — particularly levels 3 and above — is the more productive target than kick.

### 5.2 Magnitude alone does not predict recovery difficulty

At matched magnitude, recovery time for both kick and torque splits into two clusters rather than following a smooth trend — for example, kick-L4 episodes at magnitude 1.1–1.3 m/s show recovery times of both 0 and up to 45 steps. Disturbance direction is sampled uniformly in 3D per episode but is not currently recorded in evaluation output, so this cannot be confirmed directly from this sweep. The working hypothesis is that a disturbance aimed mostly along an axis the hover task is less sensitive to (e.g., a kick along the vertical axis, or a torque about yaw) does comparatively little damage regardless of its magnitude, while the same magnitude aimed at roll/pitch is substantially more destabilizing. This would mean magnitude-vs-effect, on its own, understates how much a well-timed but small disturbance can matter, and overstates how dangerous a large but well-aimed one might not be. Recommended follow-up: log the sampled disturbance direction in `run_episode()`'s output and re-run this sweep to test the hypothesis directly.

### 5.3 Methodology cross-check

The pooled crash rate from this forced sweep (21.8%) falls within the 18–23% range already reported for `tiltfix2` under the standard random-sampling evaluation. This is a useful sanity check: the forced-sweep methodology, which trades training-distribution fidelity for even per-bucket coverage, produces a consistent aggregate answer while additionally revealing the type/level structure a random sample of the same size would not reliably resolve.

## 6. Open Items and Next Steps

- **Late-instability pattern (unresolved):** the `tiltfix3` training run surfaced episodes that recover cleanly from a disturbance and then destabilize again later with no new disturbance event — a candidate marginal-stability issue distinct from anything measured in this report, since this report evaluates `tiltfix2`. Needs its own targeted investigation (a demo/diagnostic run against `tiltfix3` was in progress when this report was compiled) before deciding whether it needs a reward-shaping change or something else.
- **Direction-sensitivity hypothesis (Section 5.2):** not yet confirmed. Requires logging disturbance direction per episode and re-sweeping.
- **Torque L4–L5 scope decision:** given how extreme peak tilt gets at these levels, worth an explicit decision on whether these magnitudes are intended to be within the policy's recoverable envelope, or whether they should be treated as an intentionally out-of-scope severe tier (the same question already raised for kick L4–L5 in earlier diagnostics, now more clearly applicable to torque).

## 7. Conclusion

The current champion checkpoint (`tiltfix2`) fully masters wind disturbances, handles velocity kicks well up to moderate severity, and has a clear, quantified weakness in torque disturbances at moderate-to-high severity. The forced type/level sweep methodology used here gives a reproducible, evenly-sampled basis for these numbers, consistent with prior random-sampling evaluations of the same checkpoint. The most actionable next steps are investigating the torque failure mode specifically, and testing whether disturbance direction — not just magnitude — is a first-order factor in recovery difficulty.

---

*Reproducibility: model `hover_stabilize_ppo_seed0_disturbance_3x5_tiltfix2.zip`, git commit `5890dc1`, stage preset `disturbance_3x5`, seed 0, 40 episodes per bucket (600 total). See `source_manifest.json` for the full record.*
