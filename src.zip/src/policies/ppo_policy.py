"""
PPO policy construction.

This is the only file that knows we're using PPO specifically. Swapping to
SAC (or anything else in SB3) later means writing a sibling
`build_sac(env, config)` function with the same signature and pointing the
training script at it — the env and action space don't change at all.
"""

from stable_baselines3 import PPO
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.vec_env import VecEnv

from src.config import PPOConfig


def build_ppo(
    env,
    ppo_config: PPOConfig,
    tensorboard_log: str | None = None,
    seed: int | None = None,
) -> PPO:
    if isinstance(env, VecEnv):
        # Already vectorized -- e.g. hover_train.py's --n-envs path builds a
        # SubprocVecEnv where each sub-env is already individually
        # Monitor-wrapped inside its own process (see make_hover_env()).
        # Wrapping again here would double-count episode stats (SB3's
        # ep_rew_mean/ep_len_mean logging reads Monitor's own bookkeeping,
        # and a double-wrap makes that bookkeeping wrong, not just
        # redundant) -- so skip it for the already-vectorized case.
        monitored_env = env
    else:
        monitored_env = Monitor(env)
    model = PPO(
        policy="MlpPolicy",
        env=monitored_env,
        learning_rate=ppo_config.learning_rate,
        n_steps=ppo_config.n_steps,
        batch_size=ppo_config.batch_size,
        n_epochs=ppo_config.n_epochs,
        gamma=ppo_config.gamma,
        gae_lambda=ppo_config.gae_lambda,
        clip_range=ppo_config.clip_range,
        ent_coef=ppo_config.ent_coef,
        policy_kwargs={"net_arch": ppo_config.net_arch},
        tensorboard_log=tensorboard_log,
        verbose=1,
        device='cpu',
        seed=seed,
    )
    return model
